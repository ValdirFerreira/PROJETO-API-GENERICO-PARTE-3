﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Data.Entidades
{
    public class InputModel
    {
        public string Email { get; set; }

        public string Password { get; set; }
    }
}
